/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapp;

//It differ depending on NetBeans setup

 import java.util.Scanner; 
/**
 *
 * @author lutho
 */
public class MainApp {
    public static void main (String[] args ) {
        
        // Allows user to enter information
        Scanner input = new Scanner(System.in) ; 
        
        //Object of Login class and call its method 
        Login login = new Login(); 
        
        //---REGISTRATION SECTION---
        System.out.println("===USER REGISTRATION ===");
        
        System.out.print("Enter a username: ");
        String username = input.nextLine();
        
        System.out.print("Enter a password: ");
        String password = input.nextLine();
        
        System.out.print("Enter your South African phone number (+27...): ");
        String phone = input.nextLine();
        
        //The registerUser method is called and store the message it returns
        String response = login.registerUser(username, password, phone);
        
        //The registration message should be showned 
        System.out.println(response);
        
        //---LOGIN SECTION---
        System.out.println("/n==USER LOGIN==");
        
        System.out.print("Enter your username: ");
        String loginUsername = input.nextLine ();
        
        System.out.print("Enter your password: ");
        String loginPassword = input.nextLine();
        
        // The loginUser will be called to check if the details match the stored ones
        boolean loggedIn = login.loginUser(loginUsername, loginPassword );
        
        //The correct login message must be printed out 
        
        String loginMessage = login.returnLoginStatus(loggedIn);
        System.out.println(loginMessage );
                
    } 
        

}
